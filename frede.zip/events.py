from playsound import *
from level import *


def check_event(event):
    print(event)
    x, y = event.x, event.y
    if x in range(800, 810) and y in range(380, 390):
        playsound('D:/mshkfrede/sounds/nos_frede.wav')
    if freddy_active:
        if x in range(720, 730) and y in range(660, 670):
            playsound('D:/mshkfrede/sounds/nos_frede.wav')
    if bonnie_active:
        if x in range(600, 610) and y in range(690, 700):
            playsound('D:/mshkfrede/sounds/nos_bonni.wav')
    if chica_active:
        if x in range(960, 970) and y in range(660, 670):
            playsound('D:/mshkfrede/sounds/kluv_chici.wav')