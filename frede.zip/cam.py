cam_mshkfrede = Tk()
cam_mshkfrede.title = 'Freddys Comeback'
cam_mshkfrede.geometry('1920x1080')
cam_mshkfrede.resizable(False, False)

cam_img = ImageTk.PhotoImage(Image.open('static.gif'))
static = Label(image=cam_img)
static.pack()


def open_and_close_cam(button):
    count = 0
    if button:
        count += 1
        if count % 2 != 0:
            main_mshkfrede.destroy()
            cam_mshkfrede.mainloop()
        else:
            cam_mshkfrede.destroy()
            main_mshkfrede.mainloop()