freddy_active = True
bonnie_active = True
chica_active = True