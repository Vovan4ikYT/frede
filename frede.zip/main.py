from tkinter import *
from PIL import Image, ImageTk

from events import *
from level import *

main_mshkfrede = Tk()
main_mshkfrede.title('Freddys Comeback')
main_mshkfrede.geometry('1920x1080')
main_mshkfrede.iconbitmap('frede.ico')
main_mshkfrede.resizable(False, False)

canvas = Canvas(main_mshkfrede, width=1920, height=1080, bg='black')
canvas.pack(expand=YES, fill=BOTH)
office = ImageTk.PhotoImage(Image.open('office.jpg'))
canvas.create_image(0, 0, image=office, anchor='nw')

if freddy_active:
    frede = ImageTk.PhotoImage(Image.open('plush/plush_frede.png'))
    canvas.create_image(742, 675, image=frede, anchor='center')
if bonnie_active:
    bonnie = ImageTk.PhotoImage(Image.open('plush/plush_bonnie.png'))
    canvas.create_image(600, 699, image=bonnie, anchor='center')
if chica_active:
    chica = ImageTk.PhotoImage(Image.open('plush/plush_chica.png'))
    canvas.create_image(964, 675, image=chica, anchor='center')

cam_button = ImageTk.PhotoImage(Image.open('cam_button.png'))
cam_activate = Button(canvas, image=cam_button,
                      command=lambda: playsound('D:/mshkfrede/sounds/cam.wav'))
cam_activate.grid(padx=1305, pady=980)

main_mshkfrede.bind('<Button-1>', check_event)

main_mshkfrede.mainloop()